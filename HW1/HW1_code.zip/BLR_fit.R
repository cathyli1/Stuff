library(mvtnorm)
library(coda)

args <- commandArgs(TRUE)

cat(paste0("Command-line arguments:\n"))
print(args)

####
# sim_start ==> Lowest simulation number to be analyzed by this particular batch job
###

#######################
sim_start <- 1000
length.datasets <- 200
#######################

if (length(args)==0){
  sinkit <- FALSE
  sim_num <- sim_start + 1
  set.seed(1330931)
} else {
  # Sink output to file?
  sinkit <- TRUE
  # Decide on the job number, usually start at 1000:
  sim_num <- sim_start + as.numeric(args[1])
  # Set a different random seed for every job number!!!
  set.seed(762*sim_num + 1330931)
}
k=0
"log.post.density"<- function(beta1,m,y,X,beta.0,Sigma.0)
{
  p<-t(y)%*%(X%*%beta1)-t(m)%*%log(1+exp(X%*%beta1))
  -1/2*t(beta1-beta.0)%*%solve(Sigma.0)%*%(beta1-beta.0)
  return(p)
}
"bayes.logreg" <- function(m,y,X,beta.0,Sigma.0,
                           niter=11000,burnin=1000,
                           print.every=1000,retune=100,
                           verbose=TRUE){
  beta.curr<-beta.0
  n.accept<-0
  nsamples<-niter+burnin
  beta.draws<-matrix(rep(NA,2*nsamples),ncol=2)
  v_square<-1
  flag<-FALSE
  for(i in 1:nsamples){
    beta.prop<-t(rmvnorm(n=1,mean=beta.curr,sigma=v_square*diag(2)))
    log.alpha<-log.post.density(beta1=beta.prop,m=m,y=y,X=X,beta.0=beta.0,Sigma.0=Sigma.0)-
      log.post.density(beta1=beta.curr,m=m,y=y,X=X,beta.0=beta.0,Sigma.0=Sigma.0)
    log.u<-log(runif(1))
    if(log.u<log.alpha){
      beta.curr<-beta.prop
      n.accept<-n.accept+1
    }
    beta.draws[i,]<-beta.curr
    #tune
    
    acceptance.rate=0
    
    if(i%%retune==0 & i<=burnin & !flag){
      acceptance.rate<-round(n.accept/retune,2)
      if(acceptance.rate>=0.3 & acceptance.rate<=0.6){
        cat(paste0("Acceptance rate is:",100*round(n.accept/retune,2),"%\n","v_sqaure is: ",v_square,"\n","i is: ",i,"\n"))
        flag<-TRUE
        k<-i
      }
      else {if(acceptance.rate<=0.3){
        v_square<-v_square/exp(1)
        n.accept<-0
      }
      else {v_square<-exp(1)*v_square
            n.accept<-0}
    }
    }
    
    
    if(i%%print.every==0){
      cat(paste0(i," iterations has been done...\n"))
    }
  }
  beta1_q<-quantile(beta.draws[-(k+1000),1],probs=seq(0.01,0.99,0.01))
  beta2_q<-quantile(beta.draws[-(k+1000),2],probs=seq(0.01,0.99,0.01))
  write.table(cbind(beta1_q,beta2_q),file=paste0("results/blr_res_",sim_num,".csv"),sep=",",col.names=FALSE,row.names=FALSE)
}

dat<-read.csv(paste0("data/blr_data_",sim_num,".csv"))
y<-dat$y
X<-as.matrix(dat[,3:4])
m<-dat$n
beta.0=c(0,0)
Sigma.0<-diag(2)

bayes.logreg(m=m,y=y,X=X,beta.0=beta.0,Sigma.0=Sigma.0
             ,niter=11000,burnin=1000,
             print.every=1000,retune=100,verbose=TRUE)