library(lattice)
library(coda)
library(mvtnorm)
"log.post.density"<- function(beta1,y,X,beta.0,Sigma.0)
{
  p<-t(y)%*%(X%*%beta1)-sum(log(1+exp(X%*%beta1)))-1/2*t(beta1-beta.0)%*%solve(Sigma.0)%*%(beta1-beta.0)
  return(p)
}

dat<-read.table("breast_cancer.txt",header=TRUE)
X<-as.matrix(dat[,1:10])
X<-cbind(rep(1,569),X)
y<-rep(0,nrow(X))
y[dat[,11]=="M"]<-1
names(dat)<-c("x1","x2","x3","x4","x5","x6","x7","x8","x9","x10","y")
fit<-glm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10,data=dat,family=binomial())
sig<-vcov(fit)
beta.0<-rep(0,11)
Sigma.0<-diag(rep(1000,11))

"bayes.logreg" <- function(y,X,beta.0,Sigma.0,
                           niter=10000,burnin=1000,
                           retune=100,
                           verbose=TRUE)
  {
  beta.curr<-beta.0
  n.accept<-0
  nsamples<-niter+burnin
  beta.draws<-matrix(rep(NA,11*nsamples),ncol=11)
  v_square<-1
  flag<-FALSE
  for(i in 1:nsamples){
    beta.prop<-t(rmvnorm(n=1,mean=beta.curr,sigma=v_square*sig))
    log.alpha<-log.post.density(beta1=beta.prop,y=y,X=X,beta.0=beta.0,Sigma.0=Sigma.0)-
      log.post.density(beta1=beta.curr,y=y,X=X,beta.0=beta.0,Sigma.0=Sigma.0)
    log.u<-log(runif(1))
    if(log.u<log.alpha){
      beta.curr<-beta.prop
      n.accept<-n.accept+1
    }
    beta.draws[i,]<-beta.curr
    #tune
    
    acceptance.rate=0
    
    if(i%%retune==0 & i<=burnin & !flag){
      acceptance.rate<-round(n.accept/retune,2)
      if(acceptance.rate>=0.3 & acceptance.rate<=0.6){
        cat(paste0("Acceptance rate is:",100*round(n.accept/retune,2),"%\n","v_sqaure is: ",v_square,"\n","i is: ",i,"\n"))
        flag<-TRUE
      }
      else if(acceptance.rate<=0.3){
        v_square<-v_square/exp(1)
        n.accept<-0
      }
      else {v_square<-exp(1)*v_square
            n.accept<-0}
    }
  }
  
  for(i in 1:11)
    {plot(mcmc(beta.draws[,i]))
     cat(paste0("ess of beta",i," is: ",round(effectiveSize(beta.draws[,i]),1),"\n"))
    }
  write.table(beta.draws,"betas.csv",sep=",",col.names=FALSE)
  
  }
bayes.logreg(y,X,beta.0,Sigma.0,
             niter=50000,burnin=1000,
             retune=100,
             verbose=TRUE)
betas<-read.table("betas.csv",sep=",")
betas<-betas[-(1:1000),2:12] #now betas is 10000*11 matrix
acf(betas[,11],lag.max=1,plot=FALSE)
#Predictive Check
size<-sample(1:50000, size=10000, replace=FALSE)
y_post<-matrix(rep(0,length(size)*569),ncol=569)
betas1<-as.matrix(betas[size,])
mu_post<-t(sapply(1:length(size),function(u){X%*%t(betas1)[,u]}))
#mu_post is estimated expectation of y
u<-matrix(runif(569*length(size)),ncol=569)
for(i in 1:length(size))
{for(j in 1:569)
{if(mu_post[i,j]>=u[i,j]) y_post[i,j]<-1
else y_post[i,j]<-0}}
y_post_mean<-apply(y_post,1,mean)
hist(y_post_mean)
expect_y_real<-mean(y)
abline(v=expect_y_real,col="red")
p_val<-2*sum(y_post_mean>expect_y_real)
p_val

proportion_m<-sum(y_post[,])/(569*10000)
proportion_m #this is the proportion of "malignant" in posterior y 

#To see which covariates are related to the cancer diagnostic, we have two ways.
#i)
cor(cbind(y,X)) #this could see the correlation of y and X
#ii) See if 95% central credible interval covers 0.
qbetas<-matrix(rep(0,22),ncol=2)
for(j in 1:11)
{qbetas[j,]<-quantile(betas[,j],c(0.025,0.975))}
qbetas


